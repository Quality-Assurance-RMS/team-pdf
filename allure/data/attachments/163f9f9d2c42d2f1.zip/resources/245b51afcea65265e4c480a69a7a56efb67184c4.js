a["CONNECTED\nversion:1.2\nheart-beat:0,0\n\n\u0000"]
